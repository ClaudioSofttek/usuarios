import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { MenuComponent } from './menu/menu.component';



const routes: Routes = [
  {
    path: 'usuarios',
    loadChildren: () => import('./usuarios/usuarios.module').then( m => m.UsuariosModule )
  },
  {
    path: 'menu',
    component: MenuComponent
  },
 
  {
    path: '**',
    // component: ErrorPageComponent
    redirectTo: 'menu'
  }
]

@NgModule({
  declarations: [
    MenuComponent
  ],
  imports: [
    RouterModule.forRoot( routes ),
    
   
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
