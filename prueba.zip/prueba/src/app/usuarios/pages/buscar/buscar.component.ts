import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buscar',
  templateUrl: './buscar.component.html',
  
})
export class BuscarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
