import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListadoComponent } from './pages/listado/listado.component';
import { HomeComponent } from './pages/home/home.component';
import { BuscarComponent } from './pages/buscar/buscar.component';
import { UsuariosRoutingModule } from './usuarios-routing.module';
import { FormsModule } from '@angular/forms';
import { UppercasePipe } from './pipes/uppercase.pipe';




@NgModule({
  declarations: [
    ListadoComponent,
    HomeComponent,
    BuscarComponent,
    UppercasePipe
    
    
  ],
  imports: [
    CommonModule,
    UsuariosRoutingModule,
    FormsModule,
  
  ], 
  exports:[
    
  ]
})
export class UsuariosModule { }
